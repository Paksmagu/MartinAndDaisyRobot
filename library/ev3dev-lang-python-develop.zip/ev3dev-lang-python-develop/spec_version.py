# ~autogen spec_version
spec_version = "1.2.0"
kernel_versions = { 
    "11-ev3dev"
    "11-rc1-ev3dev"
    }

# ~autogen
